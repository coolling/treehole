self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d1d23cc9d7226850fd96c0b93373f565",
    "url": "./index.html"
  },
  {
    "revision": "161ff993fe0b43af596d",
    "url": "./static/css/main.795c7621.chunk.css"
  },
  {
    "revision": "18ad473844ed1e3bcbbc",
    "url": "./static/js/2.be6d7a3a.chunk.js"
  },
  {
    "revision": "161ff993fe0b43af596d",
    "url": "./static/js/main.513bc503.chunk.js"
  },
  {
    "revision": "0a49b281163d978bbe5b",
    "url": "./static/js/runtime-main.353cc09e.js"
  },
  {
    "revision": "2adf99ad31c6c42c5c57bc5e4c40b1e0",
    "url": "./static/media/bgi.2adf99ad.png"
  },
  {
    "revision": "952c21abac84b885954ce707962ba443",
    "url": "./static/media/musicbgi.952c21ab.png"
  },
  {
    "revision": "f0e25a67bccd1eba051bc1a534e13440",
    "url": "./static/media/musicword.f0e25a67.png"
  },
  {
    "revision": "768f0f244dcc90ad0415f333a27fdfa3",
    "url": "./static/media/mybgi.768f0f24.png"
  },
  {
    "revision": "e563f6113c87deaa39f8e80ce26e56d6",
    "url": "./static/media/otherbgi.e563f611.png"
  },
  {
    "revision": "3abbdf1e3be9b15b94f8a3c94a99f032",
    "url": "./static/media/shu2.3abbdf1e.jpg"
  },
  {
    "revision": "09527a3db07c2e8f805bd45f86d745cf",
    "url": "./static/media/tree.09527a3d.png"
  }
]);